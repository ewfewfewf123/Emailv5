# Emailv4

An Android email-account manager for accounts you own.

## Features
- Import paired CSV/TXT rows as `email,password` (optional third/fourth columns: incoming server and protocol).
- Import email-only and password-only lists separately. They are encrypted locally and are never cross-combined.
- Provider presets for Gmail, Outlook/Hotmail, Yahoo, Videotron, Bell/Sympatico, SaskTel, and custom IMAP/POP.
- AES-GCM encrypted local storage backed by the Android Keystore.
- User-initiated connection check for one selected account, manual verified status, and recent inbox reading.

## Provider notes
- Gmail and Yahoo commonly require an app password or OAuth authorization; normal account passwords may not work.
- Microsoft consumer mail requires modern OAuth2 in many accounts. This starter uses IMAP password authentication and does not yet implement Microsoft's OAuth sign-in, so Outlook/Hotmail connection may be rejected.
- Videotron: IMAP `imap.videotron.ca:993` (SSL/TLS), SMTP `smtp.videotron.ca:465`.
- Bell/Sympatico: IMAP preset `imap.bell.net:993` (SSL/TLS).
- SaskTel: legacy SaskTel documentation lists `mail.sasktel.net` as the incoming POP server; Emailv4 presets POP3S on port 995. Confirm current access details with SaskTel if this does not connect.
- Custom providers can override the incoming server and choose IMAPS or POP3S.

## Import formats
Paired accounts:
```csv
email,password
you@example.com,app-password
```
Optional columns:
```csv
email,password,server,protocol
you@example.com,app-password,imap.example.com,IMAPS
```
Email-only files: one email address per line.
Password-only files: one password per line.

**Security:** Keep account files private. Never commit real credentials to GitHub or share them in chat. Separate lists are not combined into password-guessing batches. Connection checks are initiated individually by the user.

## Build
GitHub Actions builds a debug APK on pushes to `main` or by manual workflow dispatch. Open Actions, select the successful run, and download the `Emailv4-debug` artifact.
